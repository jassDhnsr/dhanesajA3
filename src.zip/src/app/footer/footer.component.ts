import { Component, OnInit } from '@angular/core';
import { dhanesaj } from '../dhanesaj';

@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.css']
})
export class FooterComponent implements OnInit {

  bio : dhanesaj = {
    sname: "Jaspinder", sid: "991486065", slogin: "dhanesaj", 
    scampus: "Davis", stitle: "dhanesajA3"
  }

  constructor() { }

  ngOnInit() {
  }

}
