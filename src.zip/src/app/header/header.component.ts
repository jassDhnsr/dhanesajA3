import { Component, OnInit } from '@angular/core';
import { dhanesaj } from '../dhanesaj';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

bio : dhanesaj = {
  sname: "Jaspinder", sid: "991486065", slogin: "dhanesaj", 
  scampus: "Davis", stitle: "dhanesajA3"
}

  constructor() { }

  ngOnInit() {
  }

}
