import { Component, OnInit } from '@angular/core';
import { MYBOOKS} from 'src/assets/data/myBooks';
import { BooksInfo } from '../bookinfo';

@Component({
  selector: 'app-dhanesaj',
  templateUrl: './dhanesaj.component.html',
  styleUrls: ['./dhanesaj.component.css']
})
export class DhanesajComponent implements OnInit {
  mybooks = MYBOOKS;
  classPicked: BooksInfo;
  
  constructor() { }


  ngOnInit() {
    this.onButtonClick(0);
    
  }
  
    
  ngAfterViewInit() {
    var divs = document.getElementById("myList").getElementsByTagName("div");
    for (let x=0; x < divs.length; x++) {
      divs[x].style.display = "none";
    }
  }

  onClickMe(index) {
    var divs = document.getElementById("myList").getElementsByTagName("div");

    if (divs[index].style.display == 'none'){
      divs[index].style.display = 'block';
    } 
    else {
      divs[index].style.display = 'none';
    }  
  }

  onButtonClick(index){
    this.classPicked = {
      bname: this.mybooks[index].bname,
      bauthor: this.mybooks[index].bauthor,   
      bgenre: this.mybooks[index].bgenre,
      byear: this.mybooks[index].byear,
      bpic: this.mybooks[index].bpic    
    }
  }
}